Deployable Telegram Bot
========================
1. Upload this ZIP to Railway.app or Pella.dev
2. Set Environment Variables:
   - API_ID
   - API_HASH
   - BOT_TOKEN
3. Deploy and enjoy always-on hosting!
