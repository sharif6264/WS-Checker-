#!/usr/bin/env python3
import os
import asyncio
from telethon import TelegramClient, events

API_ID = int(os.getenv("API_ID", "123456"))
API_HASH = os.getenv("API_HASH", "your_api_hash")
BOT_TOKEN = os.getenv("BOT_TOKEN", "your_bot_token")

bot = TelegramClient("bot", API_ID, API_HASH).start(bot_token=BOT_TOKEN)

@bot.on(events.NewMessage(pattern='/start'))
async def start(event):
    await event.reply("🤖 Bot is online and running 24/7!")

print("🚀 Bot started successfully!")
bot.run_until_disconnected()
